package com.ust.test;

import java.util.List;
import java.util.Set;

import com.mongodb.DB;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;

public class MongoMain {

	public static void main(String[] args) {

		
		System.out.println("Hello");
		
		MongoClient mongoClient = new MongoClient("127.0.0.1", 27017);
		
		List<String> databases = mongoClient.getDatabaseNames();

		 
		for (String dbName : databases) {
		    System.out.println("Database: " + dbName);
		     
		  DB db = mongoClient.getDB(dbName);

		     
		    Set<String> collections = db.getCollectionNames();
		    for (String colName : collections) {
		        System.out.println("\t + Collection: " + colName);
		    }
		}
		 
	
		
	}

}
