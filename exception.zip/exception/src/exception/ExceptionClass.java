package exception;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ExceptionClass {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the date");
		String date = in.next();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date2 = dateFormat.parse(date);
			System.out.println(date2);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("date format error");
		}

	}

}
