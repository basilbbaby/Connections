package exception;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateValidator {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		String dateFromat;
		System.out.println("enter the date");
		String date = in.next();
			
			if(date == null){
				System.out.println("empty");
			}
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.setLenient(false);
			
			try {
				
				//if not valid, it will throw ParseException
				Date date1 = sdf.parse(date);
				System.out.println(date1);
			
			} catch (ParseException e) {
				
				e.printStackTrace();
				System.out.println("parse error");;
			}
	
		}
		
		
		
	}


